package com.vzw.ns.dto;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class UpdateConfigRequestTest {

    @Test
    @DisplayName("Setters and Getters: Should correctly assign and retrieve values")
    void testGettersAndSetters() {
        // Arrange
        UpdateConfigRequest request = new UpdateConfigRequest();
        List<Map<String, Object>> marketKpis = new ArrayList<>();
        
        Map<String, Object> kpiData = new HashMap<>();
        kpiData.put("kpi_name", "Retainability");
        kpiData.put("threshold", 98.5);
        marketKpis.add(kpiData);

        // Act
        request.setTechnology("5G");
        request.setVendor("Samsung");
        request.setRegion("Northeast");
        request.setReq_type("UPDATE");
        request.setRequest_by("Z123456");
        request.setMarket_kpis(marketKpis);

        // Assert
        assertEquals("5G", request.getTechnology());
        assertEquals("Samsung", request.getVendor());
        assertEquals("Northeast", request.getRegion());
        assertEquals("UPDATE", request.getReq_type());
        assertEquals("Z123456", request.getRequest_by());
        assertEquals(1, request.getMarket_kpis().size());
        assertEquals("Retainability", request.getMarket_kpis().get(0).get("kpi_name"));
    }

    @Test
    @DisplayName("Lombok: Should verify toString contains all field names")
    void testToString() {
        UpdateConfigRequest request = new UpdateConfigRequest();
        request.setTechnology("LTE");
        request.setVendor("Ericsson");

        String toStringResult = request.toString();

        assertNotNull(toStringResult);
        assertTrue(toStringResult.contains("technology=LTE"));
        assertTrue(toStringResult.contains("vendor=Ericsson"));
        assertTrue(toStringResult.contains("market_kpis="));
    }

    @Test
    @DisplayName("Lombok: Should verify equals and hashCode logic")
    void testEqualsAndHashCode() {
        UpdateConfigRequest req1 = new UpdateConfigRequest();
        req1.setTechnology("5G");
        req1.setVendor("Nokia");

        UpdateConfigRequest req2 = new UpdateConfigRequest();
        req2.setTechnology("5G");
        req2.setVendor("Nokia");

        UpdateConfigRequest req3 = new UpdateConfigRequest();
        req3.setTechnology("4G");

        // Assert equality
        assertEquals(req1, req2);
        assertEquals(req1.hashCode(), req2.hashCode());
        
        // Assert inequality
        assertTrue(!req1.equals(req3));
    }

    @Test
    @DisplayName("Edge Case: Should handle empty market_kpis list")
    void testEmptyMarketKpis() {
        UpdateConfigRequest request = new UpdateConfigRequest();
        request.setMarket_kpis(new ArrayList<>());

        assertNotNull(request.getMarket_kpis());
        assertTrue(request.getMarket_kpis().isEmpty());
    }
}