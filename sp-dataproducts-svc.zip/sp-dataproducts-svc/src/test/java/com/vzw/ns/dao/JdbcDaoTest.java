package com.vzw.ns.dao;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.SQLException;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class JdbcDaoTest {

    @Mock
    private DataSource dataSource;

    @Mock
    private DataSource dataSourceBackup;

    @Mock
    private Connection connection;

    @Mock
    private DatabaseMetaData metaData;

    @InjectMocks
    private JdbcDao jdbcDao;

    @Test
    void testSetDataSource() {
        DataSource testDataSource = mock(DataSource.class);
        jdbcDao.setDataSource(testDataSource);
        assertEquals(testDataSource, jdbcDao.getDataSource());
    }

    @Test
    void testGetDataSource() {
        assertEquals(dataSource, jdbcDao.getDataSource());
    }

    @Test
    void testSetDataSourceBackup() {
        DataSource testBackupDataSource = mock(DataSource.class);
        jdbcDao.setDataSourceBackup(testBackupDataSource);
        assertEquals(testBackupDataSource, jdbcDao.getDataSourceBackup());
    }

    @Test
    void testGetDataSourceBackup() {
        assertEquals(dataSourceBackup, jdbcDao.getDataSourceBackup());
    }
    
    @Test
    void testLoggerNotNull() {
        assertNotNull(JdbcDao.logger);
    }
    
    @Test
    void testGetConnection_PrimarySuccess() throws SQLException {
        when(dataSource.getConnection()).thenReturn(connection);

        Connection result = jdbcDao.getConnection();

        assertSame(connection, result);
        verify(dataSource, times(1)).getConnection();
        verifyNoInteractions(dataSourceBackup);
    }

    @Test
    void testGetConnection_PrimaryFails_BackupSuccess() throws SQLException {
        when(dataSource.getConnection()).thenThrow(new SQLException("primary failed"));
        when(dataSourceBackup.getConnection()).thenReturn(connection);

        Connection result = jdbcDao.getConnection();

        assertSame(connection, result);
        verify(dataSource, times(1)).getConnection();
        verify(dataSourceBackup, times(1)).getConnection();
    }

    @Test
    void testGetConnection_PrimaryFails_BackupFails() throws SQLException {
        when(dataSource.getConnection()).thenThrow(new SQLException("primary failed"));
        when(dataSourceBackup.getConnection()).thenThrow(new SQLException("backup failed"));

        assertThrows(SQLException.class, () -> jdbcDao.getConnection());

        verify(dataSource, times(1)).getConnection();
        verify(dataSourceBackup, times(1)).getConnection();
    }
}
