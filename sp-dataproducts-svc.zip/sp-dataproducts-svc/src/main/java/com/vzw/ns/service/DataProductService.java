package com.vzw.ns.service;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.stereotype.Service;

import com.vzw.ns.dto.ConfigRequest;
import com.vzw.ns.dto.KpiRequest;
import com.vzw.ns.dto.KpiResponse;
import com.vzw.ns.dto.UpdateConfigRequest;


@Service
public interface DataProductService {
	


	public KpiResponse getAffectedKpiData(KpiRequest request);

	public Map<String, Object> getSleepyCellConfigXlpt(ConfigRequest request);

	public Map<String, Object> updateSleepyCellConfigXlpt(UpdateConfigRequest request);
	
	
}
