package com.vzw.ns.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.vzw.ns.dao.DataProductDao;
import com.vzw.ns.dto.*;
import com.vzw.ns.service.DataProductService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Component
public class DataProductServiceImpl implements DataProductService {
    
    // Define Logger
    private static final Logger logger = LoggerFactory.getLogger(DataProductServiceImpl.class);

    @Autowired
    private ObjectMapper objectMapper;
    
    @Autowired
    private DataProductDao dataProductDao;

    @Transactional(readOnly = true)
    @Override
    public KpiResponse getAffectedKpiData(KpiRequest request) {
        String flowType = request.getResolvedType();
        String userId = request.getUserId();
        String eventNodeId = request.getEventNodeId();
        Integer finalSanitizedDu = request.getSanitizedDu();
        String marketCsv = request.getMarketCsv();
        String geofenceNodeCsv = request.getGeofenceNodeIdsCsv();

        logger.info(">>> Entering getAffectedKpiData | Type: {} | EventNodeID: {} | User: {} | DateRange: {} to {}",
                flowType, eventNodeId, userId, request.getStartDate(), request.getEndDate());

        try {
            String validationError = request.getValidationError();
            if (validationError != null) {
                logger.warn("Validation failed: {}", validationError);
                throw new IllegalArgumentException(validationError);
            }

            List<Map<String, Object>> rawData = dataProductDao.fetchKpiData(
                    flowType,
                    eventNodeId,
                    finalSanitizedDu,
                    marketCsv,
                    geofenceNodeCsv,
                    request.getStartDate(),
                    request.getEndDate(),
                    request.getSeverity()
            );

            if (rawData == null || rawData.isEmpty()) {
                logger.info("No KPI records found in DB for Type: {}", flowType);
                return new KpiResponse(new ArrayList<>());
            }

            logger.info("Successfully retrieved {} raw records from DAO for Type: {}", rawData.size(), flowType);

            Map<String, GroupedKpiData> groupedMap = new LinkedHashMap<>();

            for (Map<String, Object> row : rawData) {
                String affectedKpi = Objects.toString(row.get("AFFECTED_KPI"), "").trim();
                if (affectedKpi.isEmpty() || "null".equalsIgnoreCase(affectedKpi)) {
                    continue;
                }

                Map<String, String> dateParts = getDateParts(Objects.toString(row.get("STARTDATE"), ""));
                String day = dateParts.get("day");
                String cellId = getCellIdentifier(row);
                String groupKey = day + "|" + cellId;

                GroupedKpiData group = groupedMap.computeIfAbsent(groupKey, k -> {
                    GroupedKpiData dto = new GroupedKpiData();
                    dto.setDay(day);
                    dto.setMarket(Objects.toString(row.get("MARKET_ID"), null));
                    dto.setEnodeb(row.get("GNODEB") != null ? String.valueOf(row.get("GNODEB")) : null);

                    Object dbDu = row.get("DU");
                    if (dbDu instanceof Number) {
                        dto.setDu(((Number) dbDu).intValue());
                    } else if (dbDu instanceof String && !((String) dbDu).trim().isEmpty()) {
                        dto.setDu(Integer.parseInt(((String) dbDu).trim()));
                    } else {
                        dto.setDu(null);
                    }

                    dto.setSector(row.get("SECTOR") != null ? ((Number) row.get("SECTOR")).intValue() : null);
                    dto.setCarrier(row.get("CARRIER") != null ? ((Number) row.get("CARRIER")).intValue() : null);
                    dto.setTechnology(Objects.toString(row.get("TECHNOLOGY"), null));
                    dto.setVendor(Objects.toString(row.get("VENDOR"), null));
                    dto.setSite_name(Objects.toString(row.get("SITE_NAME"), null));
                    dto.setSite_type(Objects.toString(row.get("SITE_TYPE"), null));
                    dto.setSeverity(Objects.toString(row.get("SEVERITY"), null));

                    String tech = dto.getTechnology();
                    String band = ("5GNR".equalsIgnoreCase(tech) || "5G".equalsIgnoreCase(tech))
                            ? Objects.toString(row.get("FREQUENCY_BAND"), null)
                            : Objects.toString(row.get("BAND_CLASS"), null);
                    dto.setBandClass(band);

                    dto.setAffectedKpisSet(new TreeSet<>());
                    dto.setAffectedKpiTicketsMap(new LinkedHashMap<>());
                    dto.setLatestStartDate(Objects.toString(row.get("STARTDATE"), ""));
                    dto.setLatestRow(row);
                    return dto;
                });

                group.getAffectedKpisSet().add(affectedKpi);

                String ticketId = Objects.toString(row.get("TICKET_ID"), "").trim();
                Object rawStatus = row.get("TICKET_CLOSE_STATUS");

                boolean isActiveTicket =
                        !ticketId.isEmpty() &&
                                (
                                        rawStatus == null ||
                                                "failure".equalsIgnoreCase(String.valueOf(rawStatus).trim())
                                );

                if (isActiveTicket) {
                    group.getAffectedKpiTicketsMap()
                            .computeIfAbsent(affectedKpi, k -> new LinkedHashSet<>())
                            .add(ticketId);
                }

                if (Objects.toString(row.get("STARTDATE"), "").compareTo(group.getLatestStartDate()) > 0) {
                    group.setLatestStartDate(Objects.toString(row.get("STARTDATE"), ""));
                    group.setLatestRow(row);
                }
            }

            List<Map<String, Object>> finalResult = groupedMap.values().stream().map(dto -> {
                Map<String, Object> item = new LinkedHashMap<>();
                List<String> latestHours = parseHoursAffected(
                        Objects.toString(dto.getLatestRow().get("HRS_AFFECTED"), "")
                );

                List<Map<String, Object>> affectedKpisList = dto.getAffectedKpisSet().stream().map(name -> {
                    Map<String, Object> kpiObj = new LinkedHashMap<>();
                    kpiObj.put("kpi_name", name);
                    kpiObj.put("hrAffected", latestHours);

                    List<String> ticketIds = new ArrayList<>(
                            dto.getAffectedKpiTicketsMap().getOrDefault(name, Collections.emptySet())
                    );
                    kpiObj.put("ticketId", ticketIds);

                    return kpiObj;
                }).collect(Collectors.toList());

                item.put("day", dto.getDay());
                item.put("market", dto.getMarket());
                item.put("enodeb", dto.getEnodeb());
                item.put("du", dto.getDu());
                item.put("sector", dto.getSector());
                item.put("carrier", dto.getCarrier());
                item.put("technology", dto.getTechnology());
                item.put("vendor", dto.getVendor());
                item.put("site_name", dto.getSite_name());
                item.put("site_type", dto.getSite_type());
                item.put("bandClass", dto.getBandClass());
                item.put("severity", dto.getSeverity());
                item.put("latestStartDate", dto.getLatestStartDate());
                item.put("summary", buildSummaryString(dto.getLatestRow(), affectedKpisList, latestHours));
                item.put("affectedKpis", affectedKpisList);
                return item;
            }).collect(Collectors.toList());

            finalResult.sort((a, b) -> {
                int res = Objects.toString(b.get("day"), "").compareTo(Objects.toString(a.get("day"), ""));
                if (res != 0) return res;

                res = Objects.toString(b.get("latestStartDate"), "").compareTo(Objects.toString(a.get("latestStartDate"), ""));
                if (res != 0) return res;

                res = Objects.toString(a.get("enodeb"), "").compareTo(Objects.toString(b.get("enodeb"), ""));
                if (res != 0) return res;

                res = compareNullableInt((Integer) a.get("du"), (Integer) b.get("du"));
                if (res != 0) return res;

                res = compareNullableInt((Integer) a.get("sector"), (Integer) b.get("sector"));
                if (res != 0) return res;

                return compareNullableInt((Integer) a.get("carrier"), (Integer) b.get("carrier"));
            });

            finalResult.forEach(m -> m.remove("latestStartDate"));

            logger.info("<<< Exiting getAffectedKpiData. Returning {} items for Type: {}", finalResult.size(), flowType);
            return new KpiResponse(finalResult);

        } catch (Exception e) {
            logger.error("CRITICAL: Failed to process KPI data for Type: {}. Error: {}", flowType, e.getMessage(), e);
            throw e;
        }
    }
    
    private String buildSummaryString(Map<String, Object> latestRow, List<Map<String, Object>> affectedKpis, List<String> hours) {
        String summaryKpis = affectedKpis.stream()
                .map(k -> Objects.toString(k.get("kpi_name"), ""))
                .collect(Collectors.joining(", "));

        String summaryHours = String.join(",", hours);

        String wowTrend = formatMbValue(Objects.toString(latestRow.get("WoW_TREND"), ""));
        String volAvg = formatMbValue(Objects.toString(latestRow.get("30D_VOLUME_AVERAGE"), ""));

        return String.format(
            "This Site observed 'Sleepy Cell' consecutive occurrences of %s and non consecutive occurrence of %s " +
            "for the past 54 Hours, excluding maintenance window, impacting %s during the %s hours " +
            "with a week-over-week trend of %s and a 30-day volume average of %s ", 
            Objects.toString(latestRow.get("SC_CONSECUTIVE_DURATION"), ""), 
            Objects.toString(latestRow.get("SLEPPYCELL_OCCUR_D"), ""), 
            summaryKpis, 
            summaryHours, 
            wowTrend, 
            volAvg
        );
    }


    private String getCellIdentifier(Map<String, Object> row) {
        Object fiveGKey = row.get("ENODEB_DU_SECTOR_CARRIER");
        if (fiveGKey != null && !fiveGKey.toString().trim().isEmpty()) {
            return fiveGKey.toString();
        }

        Object fourGKey = row.get("ENODEB_SECTOR_CARRIER");
        if (fourGKey != null && !fourGKey.toString().trim().isEmpty()) {
            return fourGKey.toString();
        }

        Object du = row.get("DU");
        if (du != null && !du.toString().trim().isEmpty()) {
            return String.join("|",
                    Objects.toString(row.get("GNODEB"), ""),
                    Objects.toString(du, ""),
                    Objects.toString(row.get("SECTOR"), ""),
                    Objects.toString(row.get("CARRIER"), ""));
        }

        return String.join("|",
                Objects.toString(row.get("GNODEB"), ""),
                Objects.toString(row.get("SECTOR"), ""),
                Objects.toString(row.get("CARRIER"), ""));
    }

    private int compareNullableInt(Integer a, Integer b) {
        return Integer.compare(a != null ? a : -1, b != null ? b : -1);
    }

    
    private Map<String, String> getDateParts(String dateStr) {
        Map<String, String> parts = new HashMap<>();
        if (dateStr == null || dateStr.trim().isEmpty() || "null".equalsIgnoreCase(dateStr)) {
            parts.put("day", null);
            parts.put("hour", null);
            return parts;
        }
        
        // Replace T with space if it's ISO format (e.g., 2026-03-21T14:00:00)
        String cleaned = dateStr.replace("T", " ");
        String[] split = cleaned.split(" ");
        
        String day = split[0];
        parts.put("day", day);
        
        if (split.length > 1) {
            String timePart = split[1];
            String hour = timePart.split(":")[0];
            // Ensure 2-digit format (e.g., "9" becomes "09")
            parts.put("hour", hour.length() == 1 ? "0" + hour : hour);
        } else {
            parts.put("hour", null);
        }
        return parts;
    }

    private List<String> parseHoursAffected(String value) {
        if (value == null || value.trim().isEmpty() || "null".equalsIgnoreCase(value)) {
            return new ArrayList<>();
        }
        
        // Splits "9,10,11" into a sorted list ["09", "10", "11"]
        return Arrays.stream(value.split(","))
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .map(s -> s.length() == 1 ? "0" + s : s)
                .distinct()
                .sorted()
                .collect(Collectors.toList());
    }

    private String formatMbValue(String value) {
        if (value == null || value.trim().isEmpty() || "null".equalsIgnoreCase(value)) {
            return "";
        }
        return value.trim() + " MB";
    }

    @Override
    public Map<String, Object> getSleepyCellConfigXlpt(ConfigRequest request) {
        logger.info(">>> Fetching Config | Tech: {} | Vendor: {} | Region: {}", 
                request.getTechnology(), request.getVendor(), request.getRegion());
        
        try {
            validateRequest(request);
            List<Map<String, Object>> rows = dataProductDao.fetchKpiConfig(
                    request.getVendor(), request.getTechnology(), request.getRegion(), request.getCategory()
            );

            if (rows == null || rows.isEmpty()) {
                logger.warn("No configuration found for criteria: Tech={}, Vendor={}, Region={}", 
                        request.getTechnology(), request.getVendor(), request.getRegion());
                Map<String, Object> notFound = new HashMap<>();
                notFound.put("message", "No data found for the given criteria");
                return notFound;
            }

            Map<String, Object> row = rows.get(0);
            Map<String, Object> response = new LinkedHashMap<>();
            response.put("technology", row.get("TECHNOLOGY"));
            response.put("vendor", row.get("VENDOR"));
            response.put("region", row.get("REGION"));
            response.put("market_kpis", Arrays.asList(parseJsonField(row.get("JSON_FORMULA")), parseJsonField(row.get("JSON_PRIORITY"))));
            response.put("national_kpis", parseJsonField(row.get("JSON_READONLY_FORMULA")));

            logger.info("<<< Successfully retrieved config for Tech: {}", request.getTechnology());
            return response;
        } catch (Exception e) {
            logger.error("Error retrieving configuration: {}", e.getMessage(), e);
            throw e;
        }
    }

    @Override
    public Map<String, Object> updateSleepyCellConfigXlpt(UpdateConfigRequest request) {
        logger.info(">>> Update Config Request | Tech: {} | User: {} | Type: {}", 
                request.getTechnology(), request.getRequest_by(), request.getReq_type());

        try {
            validateUpdateRequest(request);
            
            Map<String, Object> kpiConfig = request.getMarket_kpis().get(0);
            Map<String, Object> priorityConfig = request.getMarket_kpis().get(1);

            String jsonFormula = objectMapper.writeValueAsString(kpiConfig);
            Map<String, Object> priorityMap = new HashMap<>();
            priorityMap.put("priority_settings", priorityConfig.get("priority_settings"));
            String jsonPriority = objectMapper.writeValueAsString(priorityMap);

            logger.debug("Upserting config to DB for Vendor: {}", request.getVendor());
            Object[] params = new Object[] {
                "SleepyCell", request.getTechnology(), request.getVendor(), request.getRegion(),
                kpiConfig.get("kpi_name"), jsonFormula, priorityConfig.get("kpi_short_name"),
                jsonPriority, null, "Airwave", request.getReq_type().toUpperCase(), request.getRequest_by()
            };

            dataProductDao.upsertKpiConfig(params);

            logger.info("<<< Config Update Successful for Tech: {} by User: {}", request.getTechnology(), request.getRequest_by());
            return buildUpdateResponse(request, "success", "Your request will be reviewed by RF Team", null);

        } catch (Exception e) {
            logger.error("Update Config Failed for Tech: {}. Reason: {}", request.getTechnology(), e.getMessage());
            return buildUpdateResponse(request, "failed", null, e.getMessage());
        }
    }

    // --- Helper Methods with Internal Logging ---

    private Object parseJsonField(Object dbValue) {
        if (dbValue == null) return null;
        try {
            String jsonStr = dbValue.toString();
            if (jsonStr.trim().startsWith("{") || jsonStr.trim().startsWith("[")) {
                return objectMapper.readValue(jsonStr, Object.class);
            }
            return jsonStr;
        } catch (Exception e) {
            logger.warn("JSON parsing failed for string: {}. Returning as-is.", dbValue);
            return dbValue; 
        }
    }

    private void validateRequest(ConfigRequest request) {
        if (request.getVendor() == null || request.getTechnology() == null || 
            request.getRegion() == null || request.getCategory() == null) {
            throw new IllegalArgumentException("Required config fields should not be null");
        }
    }

    private void validateUpdateRequest(UpdateConfigRequest req) {
        if (req.getVendor() == null || req.getTechnology() == null || req.getRegion() == null 
            || req.getReq_type() == null || req.getRequest_by() == null) {
            throw new IllegalArgumentException("Required update fields missing");
        }
    }

    private Map<String, Object> buildUpdateResponse(UpdateConfigRequest req, String status, String msg, String error) {
        Map<String, Object> res = new LinkedHashMap<>();
        res.put("technology", req.getTechnology());
        res.put("vendor", req.getVendor());
        res.put("status", status);
        res.put("message", msg);
        res.put("error_message", error);
        return res;
    }

    // Other private helper methods (getDateParts, getCellIdentifier, etc.) remain as in your original code.
}