package com.vzw.ns.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class SwaggerConfigTest {

    @Test
    void customOpenAPI_returnsConfiguredInfo() {
        SwaggerConfig config = new SwaggerConfig();
        OpenAPI openAPI = config.customOpenAPI();
        assertNotNull(openAPI);

        Info info = openAPI.getInfo();
        assertNotNull(info);
        assertEquals("SP Data Product API", info.getTitle());
        assertEquals("1.0.0", info.getVersion());
        assertEquals("API documentation for SP Data Product", info.getDescription());
    }

    @Test
    void customOpenAPI_isNewInstanceEachCall() {
        SwaggerConfig config = new SwaggerConfig();
        OpenAPI o1 = config.customOpenAPI();
        OpenAPI o2 = config.customOpenAPI();
        assertNotSame(o1, o2);
    }
}