package com.vzw.ns.dao;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class DataProductDao {
	public static final Logger logger = LoggerFactory.getLogger(DataProductDao.class);
	
	@Autowired
    private JdbcTemplate jdbcTemplate;

    public List<Map<String, Object>> fetchKpiData(
            String flowType,
            String nodeId,
            Integer du,
            String marketCsv,
            String geofenceNodeCsv,
            String start,
            String end,
            String severity) {

        String sql = "{call SP_GET_SLEEPY_CELL_DATA_SPDB_4G_5G(?, ?, ?, ?, ?, ?, ?, ?)}";

        return jdbcTemplate.queryForList(
                sql,
                flowType,
                nodeId,
                du,
                marketCsv,
                geofenceNodeCsv,
                start,
                end,
                severity
        );
    }
    
    public List<Map<String, Object>> fetchKpiConfig(String vendor, String tech, String region, String category) {
        String sql = "SELECT * FROM SPDB_RULES_ADMIN sr WHERE sr.vendor = ? " +
                     "AND sr.technology = ? AND sr.region = ? AND sr.category = ? " +
                     "AND SOURCE = 'XLPT'";
        
        return jdbcTemplate.queryForList(sql, vendor, tech, region, category);
    }
    
    public void upsertKpiConfig(Object[] params) {
        String sql = "CALL SPDB_RULES_ADMIN_UPSERT(?,?,?,?,?,?,?,?,?,?,?,?)";
        jdbcTemplate.update(sql, params);
    }
	
}