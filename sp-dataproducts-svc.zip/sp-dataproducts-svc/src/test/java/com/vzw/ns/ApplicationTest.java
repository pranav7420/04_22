package com.vzw.ns;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

@SpringBootTest
class ApplicationTest {

    @Test
    @DisplayName("Context Load: Should verify that the Spring application context loads without errors")
    void contextLoads() {
        // This test will fail if any bean fails to initialize 
        // or if there are issues with @ComponentScan.
    }

    @Test
    @DisplayName("Main Method: Should verify that the main method executes without throwing exceptions")
    void mainMethodTest() {
        // This reaches 100% coverage for the Application class by executing the main method.
        // We use a mock array of arguments.
        assertDoesNotThrow(() -> Application.main(new String[] {}));
    }
}