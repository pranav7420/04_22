package com.vzw.ns.util;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class GeneralUtilityTest {
	
	@InjectMocks
	GeneralUtility fixture;

    @Mock
    private Connection connection;

    @Mock
    private ResultSet resultSet;

    @Mock
    private Statement statement;

    @Mock
    private DatabaseMetaData metaData;

    @Test
    public void testIsEmptyWithNull() {
        assertTrue(GeneralUtility.isEmpty(null));
    }

    @Test
    public void testIsEmptyWithEmptyString() {
        assertTrue(GeneralUtility.isEmpty(""));
    }

    @Test
    public void testIsEmptyWithWhitespaceOnly() {
        assertTrue(GeneralUtility.isEmpty("   "));
        assertTrue(GeneralUtility.isEmpty("\t"));
        assertTrue(GeneralUtility.isEmpty("\n"));
        assertTrue(GeneralUtility.isEmpty("  \t  \n  "));
    }

    @Test
    public void testIsEmptyWithNonEmptyString() {
        assertFalse(GeneralUtility.isEmpty("test"));
        assertFalse(GeneralUtility.isEmpty("  test  "));
        assertFalse(GeneralUtility.isEmpty("a"));
    }

    @Test
    public void testIsNonEmptyWithNull() {
        assertFalse(GeneralUtility.isNonEmpty(null));
    }

    @Test
    public void testIsNonEmptyWithEmptyString() {
        assertFalse(GeneralUtility.isNonEmpty(""));
        assertFalse(GeneralUtility.isNonEmpty("   "));
    }

    @Test
    public void testIsNonEmptyWithNonEmptyString() {
        assertTrue(GeneralUtility.isNonEmpty("test"));
        assertTrue(GeneralUtility.isNonEmpty("  test  "));
        assertTrue(GeneralUtility.isNonEmpty("a"));
    }

    @Test
    public void testTrimWithNull() {
        assertNull(GeneralUtility.trim(null));
    }

    @Test
    public void testTrimWithEmptyString() {
        assertEquals("", GeneralUtility.trim(""));
    }

    @Test
    public void testTrimWithWhitespace() {
        assertEquals("test", GeneralUtility.trim("  test  "));
        assertEquals("test", GeneralUtility.trim("\ttest\n"));
        assertEquals("", GeneralUtility.trim("   "));
    }

    @Test
    public void testTrimWithNormalString() {
        assertEquals("test", GeneralUtility.trim("test"));
        assertEquals("hello world", GeneralUtility.trim("hello world"));
    }

    @Test
    public void testCloseCRSAllNull() {
        // Should not throw any exceptions
        assertDoesNotThrow(() -> {
            GeneralUtility.closeCRS(null, null, null);
        });
    }

    @Test
    public void testCloseCRSSuccessfulClose() throws SQLException {
        // Mock successful close operations
        doNothing().when(resultSet).close();
        doNothing().when(statement).close();
        doNothing().when(connection).close();

        assertDoesNotThrow(() -> {
            GeneralUtility.closeCRS(connection, resultSet, statement);
        });

        verify(resultSet).close();
        verify(statement).close();
        verify(connection).close();
    }

    @Test
    public void testCloseCRSResultSetException() throws SQLException {
        // Mock ResultSet to throw exception on close
        doThrow(new SQLException("ResultSet close failed")).when(resultSet).close();
        doNothing().when(statement).close();
        doNothing().when(connection).close();

        assertDoesNotThrow(() -> {
            GeneralUtility.closeCRS(connection, resultSet, statement);
        });

        verify(resultSet).close();
        verify(statement).close(); // Should still be called
        verify(connection).close(); // Should still be called
    }

    @Test
    public void testCloseCRSStatementException() throws SQLException {
        doNothing().when(resultSet).close();
        doThrow(new SQLException("Statement close failed")).when(statement).close();
        doNothing().when(connection).close();

        assertDoesNotThrow(() -> {
            GeneralUtility.closeCRS(connection, resultSet, statement);
        });

        verify(resultSet).close();
        verify(statement).close();
        verify(connection).close(); // Should still be called
    }

    @Test
    public void testCloseCRSConnectionException() throws SQLException {
        doNothing().when(resultSet).close();
        doNothing().when(statement).close();
        doThrow(new SQLException("Connection close failed")).when(connection).close();

        assertDoesNotThrow(() -> {
            GeneralUtility.closeCRS(connection, resultSet, statement);
        });

        verify(resultSet).close();
        verify(statement).close();
        verify(connection).close();
    }

    @Test
    public void testCloseCRSAllExceptions() throws SQLException {
        // All close operations throw exceptions
        doThrow(new SQLException("ResultSet close failed")).when(resultSet).close();
        doThrow(new SQLException("Statement close failed")).when(statement).close();
        doThrow(new SQLException("Connection close failed")).when(connection).close();

        assertDoesNotThrow(() -> {
            GeneralUtility.closeCRS(connection, resultSet, statement);
        });

        verify(resultSet).close();
        verify(statement).close();
        verify(connection).close();
    }

    @Test
    public void testCloseCRSMixedNullAndValid() throws SQLException {
        doNothing().when(connection).close();

        // ResultSet and Statement are null, only Connection is valid
        assertDoesNotThrow(() -> {
            GeneralUtility.closeCRS(connection, null, null);
        });

        verify(connection).close();
    }
    
  
}