package com.vzw.ns.dao;

import java.sql.Connection;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class JdbcDao  
{
	
	@Autowired
    private DataSource dataSource;
    
    @Autowired(required = false)
    @Qualifier("backupDataSource")
    private DataSource dataSourceBackup;
    
    public static final Logger logger = LoggerFactory.getLogger(JdbcDao.class);

    public void setDataSource(DataSource dataSource) 
    {		
        this.dataSource = dataSource;
    }

    public DataSource getDataSource() { return dataSource; }

    public DataSource getDataSourceBackup() { return dataSourceBackup; }

    public void setDataSourceBackup(DataSource dataSourceBackup) 
    {
        this.dataSourceBackup = dataSourceBackup;
    }

    public Connection getConnection() throws SQLException
    {
    	Connection conn = null;
        try 
        {			
            conn = dataSource.getConnection();
        }
        catch(SQLException s)
        {	
            logger.debug("Failed to get Connection from primary central db. Going to try the backup now.");
            conn = dataSourceBackup.getConnection();
        }
        
        return conn;
    }
    
}