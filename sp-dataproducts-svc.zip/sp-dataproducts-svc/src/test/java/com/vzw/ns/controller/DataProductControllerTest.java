package com.vzw.ns.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertInstanceOf;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.vzw.ns.dto.ConfigRequest;
import com.vzw.ns.dto.KpiRequest;
import com.vzw.ns.dto.KpiResponse;
import com.vzw.ns.dto.UpdateConfigRequest;
import com.vzw.ns.service.DataProductService;
import com.vzw.ns.util.GeneralUtility;

@ExtendWith(MockitoExtension.class)
class DataProductControllerTest {

    @InjectMocks
    private DataProductController controller;

    @Mock
    private DataProductService dataProductService;

    @Mock
    private GeneralUtility util;

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Test
    void getAffectedKpiData_shouldReturnBadRequest_whenMandatoryFieldsMissing() {
        KpiRequest request = new KpiRequest();
        request.setNodeID(objectMapper.valueToTree("NODE_1"));
        request.setUserId(null);
        request.setStartDate("2026-03-01");
        request.setEndDate("2026-03-02");

        ResponseEntity<?> response = controller.getAffectedKpiData(request);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("Mandatory fields missing: userId, startDate, or endDate", response.getBody());
    }

    @Test
    void getAffectedKpiData_shouldReturnBadRequest_whenEventNodeIdMissing() {
        KpiRequest request = new KpiRequest();
        request.setType("event");
        request.setUserId("user1");
        request.setStartDate("2026-03-01");
        request.setEndDate("2026-03-02");

        ResponseEntity<?> response = controller.getAffectedKpiData(request);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("Mandatory fields missing for event flow: nodeID", response.getBody());
    }

    @Test
    void getAffectedKpiData_shouldReturnOk_whenServiceReturnsData() {
        KpiRequest request = new KpiRequest();
        request.setNodeID(objectMapper.valueToTree("NODE_1"));
        request.setUserId("user1");
        request.setStartDate("2026-03-01");
        request.setEndDate("2026-03-02");
        request.setSeverity("Critical");

        KpiResponse serviceResponse =
                new KpiResponse(Collections.singletonList(Collections.singletonMap("day", "2026-03-01")));

        when(dataProductService.getAffectedKpiData(request)).thenReturn(serviceResponse);

        ResponseEntity<?> response = controller.getAffectedKpiData(request);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertInstanceOf(KpiResponse.class, response.getBody());
        assertEquals(serviceResponse, response.getBody());
        verify(dataProductService).getAffectedKpiData(request);
    }

    @Test
    void getAffectedKpiData_shouldReturnBadRequest_whenServiceThrowsIllegalArgumentException() {
        KpiRequest request = new KpiRequest();
        request.setNodeID(objectMapper.valueToTree("NODE_1"));
        request.setUserId("user1");
        request.setStartDate("2026-03-01");
        request.setEndDate("2026-03-02");

        when(dataProductService.getAffectedKpiData(request))
                .thenThrow(new IllegalArgumentException("Invalid type. Supported values are: event, market, geofence"));

        ResponseEntity<?> response = controller.getAffectedKpiData(request);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("Invalid type. Supported values are: event, market, geofence", response.getBody());
    }

    @Test
    void getAffectedKpiData_shouldReturnInternalServerError_whenServiceThrowsException() {
        KpiRequest request = new KpiRequest();
        request.setNodeID(objectMapper.valueToTree("NODE_1"));
        request.setUserId("user1");
        request.setStartDate("2026-03-01");
        request.setEndDate("2026-03-02");

        when(dataProductService.getAffectedKpiData(request))
                .thenThrow(new RuntimeException("DB failure"));

        ResponseEntity<?> response = controller.getAffectedKpiData(request);

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertEquals("Error while fetching affected KPI data!", response.getBody());
    }

    @Test
    void getSleepyCellConfig_shouldReturnOk_whenServiceReturnsData() {
        ConfigRequest request = new ConfigRequest();
        request.setVendor("NOKIA");
        request.setTechnology("4G");
        request.setRegion("EAST");
        request.setCategory("SLEEPY_CELL");

        Map<String, Object> result = new HashMap<>();
        result.put("vendor", "NOKIA");
        result.put("technology", "4G");

        when(dataProductService.getSleepyCellConfigXlpt(request)).thenReturn(result);

        ResponseEntity<?> response = controller.getSleepyCellConfig(request);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(result, response.getBody());
        verify(dataProductService).getSleepyCellConfigXlpt(request);
    }

    @Test
    void getSleepyCellConfig_shouldReturnBadRequest_whenServiceThrowsIllegalArgumentException() {
        ConfigRequest request = new ConfigRequest();

        when(dataProductService.getSleepyCellConfigXlpt(request))
                .thenThrow(new IllegalArgumentException("Required fields should not be null or empty"));

        ResponseEntity<?> response = controller.getSleepyCellConfig(request);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("Required fields should not be null or empty", response.getBody());
    }

    @Test
    void getSleepyCellConfig_shouldReturnInternalServerError_whenServiceThrowsException() {
        ConfigRequest request = new ConfigRequest();
        request.setVendor("NOKIA");
        request.setTechnology("4G");
        request.setRegion("EAST");
        request.setCategory("SLEEPY_CELL");

        when(dataProductService.getSleepyCellConfigXlpt(request))
                .thenThrow(new RuntimeException("Unexpected failure"));

        ResponseEntity<?> response = controller.getSleepyCellConfig(request);

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertEquals("Internal Server Error", response.getBody());
    }

    @Test
    void updateConfig_shouldReturnOk_whenUpdateIsSuccessful() {
        UpdateConfigRequest request = new UpdateConfigRequest();
        request.setTechnology("5G");
        request.setVendor("Ericsson");
        request.setRequest_by("admin_user");

        Map<String, Object> serviceResponse = new HashMap<>();
        serviceResponse.put("status", "success");
        serviceResponse.put("message", "Your request will be reviewed by RF Team");

        when(dataProductService.updateSleepyCellConfigXlpt(request)).thenReturn(serviceResponse);

        ResponseEntity<Map<String, Object>> response = controller.updateConfig(request);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("success", response.getBody().get("status"));
        assertEquals("Your request will be reviewed by RF Team", response.getBody().get("message"));
        verify(dataProductService).updateSleepyCellConfigXlpt(request);
    }

    @Test
    void updateConfig_shouldReturnInternalServerError_whenUpdateFails() {
        UpdateConfigRequest request = new UpdateConfigRequest();

        Map<String, Object> errorResponse = new HashMap<>();
        errorResponse.put("status", "failed");
        errorResponse.put("error_message", "Database update failed");

        when(dataProductService.updateSleepyCellConfigXlpt(request)).thenReturn(errorResponse);

        ResponseEntity<Map<String, Object>> response = controller.updateConfig(request);

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("failed", response.getBody().get("status"));
        assertEquals("Database update failed", response.getBody().get("error_message"));
        verify(dataProductService).updateSleepyCellConfigXlpt(request);
    }
}