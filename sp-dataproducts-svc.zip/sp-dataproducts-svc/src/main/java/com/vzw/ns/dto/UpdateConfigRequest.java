package com.vzw.ns.dto;


import java.util.List;
import java.util.Map;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class UpdateConfigRequest {
    private String technology;
    private String vendor;
    private String region;
    private String req_type;
    private String request_by;
    private List<Map<String, Object>> market_kpis;

   
}