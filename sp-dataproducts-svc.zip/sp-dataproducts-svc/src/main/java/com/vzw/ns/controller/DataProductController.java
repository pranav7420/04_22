package com.vzw.ns.controller;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.vzw.ns.dto.ConfigRequest;
import com.vzw.ns.dto.KpiRequest;
import com.vzw.ns.dto.KpiResponse;
import com.vzw.ns.dto.UpdateConfigRequest;
import com.vzw.ns.service.DataProductService;
import com.vzw.ns.util.GeneralUtility;

@RestController
@RequestMapping("/dataProducts")
public class DataProductController {
	public static final Logger logger = LoggerFactory.getLogger(DataProductController.class);

	@Autowired
	private DataProductService dataProductService;

	
	@Autowired
	GeneralUtility util;




		@PostMapping("/getAffectedKpiData")
		public ResponseEntity<?> getAffectedKpiData(@RequestBody KpiRequest request) {
			logger.info("in controller");

			String validationError = request.getValidationError();
			if (validationError != null) {
				return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(validationError);
			}

			try {
				KpiResponse response = dataProductService.getAffectedKpiData(request);
				return ResponseEntity.ok(response);
			} catch (IllegalArgumentException e) {
				return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
			} catch (Exception e) {
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
						.body("Error while fetching affected KPI data!");
			}
		}
	    
	    @PostMapping("/sleepycell_config")
	    public ResponseEntity<?> getSleepyCellConfig(@RequestBody ConfigRequest request) {
	        try {
	            Map<String, Object> result = dataProductService.getSleepyCellConfigXlpt(request);
	            return ResponseEntity.ok(result);
	        } catch (IllegalArgumentException e) {
	            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
	        } catch (Exception e) {
	            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Internal Server Error");
	        }
	    }
	    
	    @PostMapping("/sleepycell_config/update")
	    public ResponseEntity<Map<String, Object>> updateConfig(@RequestBody UpdateConfigRequest request) {
	        Map<String, Object> response = dataProductService.updateSleepyCellConfigXlpt(request);
	        
	        if ("failed".equals(response.get("status"))) {
	            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
	        }
	        return ResponseEntity.ok(response);
	    }

}
