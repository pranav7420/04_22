package com.vzw.ns.util;

import org.springframework.stereotype.Component;

@Component
public final class AppConstants {
    private AppConstants() { /* prevent instantiation */ }

    public static final String RULE_ID = "RULE_ID";
	public static final String ENODEB_ID = "ENODEB_ID";
	public static final String SECTOR = "SECTOR";
	public static final String GNODEB_ID = "GNODEB_ID";
	public static final String EUTRANCELL = "EUTRANCELL";
	public static final String CARRIER = "CARRIER";
	public static final String VIOLATION_ID = "VIOLATION_ID";
	public static final String KPI_DATE = "KPI_DATE";
	public static final String NOTIFICATION_STATUS = "NOTIFICATION_STATUS";
	public static final String LAST_NOTIFIED_AT = "LAST_NOTIFIED_AT";
	public static final String ENGINEER_ACTION = "ENGINEER_ACTION";
	public static final String DU = "DU";
	public static final String VENDOR_4G = "4G";
	public static final String VENDOR_5G = "5G";
	public static final String ENODEB = "enodeB";
	public static final String STATUS = "status";
	public static final String MESSAGE = "message";
	public static final String ERROR = "error";
	public static final String ID_MISSING = "Maintenance ID is missing";
	public static final String FAIL_MESSAGE = "fail and 0 row(s) is/are updated.";
	public static final String FAIL = "fail";
	public static final String CREATED_BY = "CREATED_BY";
	public static final String MAINTENANCE_ID = "MAINTENANCE_ID";
	public static final String START_TIME = "START_TIME";
	public static final String END_TIME = "END_TIME";
	public static final String REASON = "REASON";
	public static final String USER_ID = "USER_ID";
	public static final String MAX_RULES = "MAX_RULES";
	public static final String IS_BLOCKED = "IS_BLOCKED";
	public static final String TOTAL_RULES = "TOTAL_RULES";
	public static final String ACTIVE_RULES = "ACTIVE_RULES";
	public static final String HR = "HR";
	public static final String KPI_CONDITION = "KPI_CONDITION";
	public static final String KPI_NAME = "KPI_NAME";
	public static final String VENDOR = "VENDOR";
	public static final String USER_TYPE = "USER_TYPE";
	public static final String RULE_EDITOR_KPI_LIST_ID = "RULE_EDITOR_KPI_LIST_ID";
	public static final String SITE_NAME = "SITE_NAME";
	public static final String SITE = "SITE";
	public static final String Y = "Y";
	public static final String N = "N";
	public static final String GNODEB = "GNODEB";
	public static final String MM_DD_YYYY = "MM/dd/yyyy";
	public static final String NO_DATA = "No Data";
	public static final String NULL_VAR = "null";
	public static final String NA = "N/A";
	public static final String DAY = "DAY";
	public static final String NAN = "NaN";	
	public static final String SUCCESS = "success";
	public static final String EMAILS = "emails";
	public static final String PHONES = "phones";
	public static final String EMAIL_ID = "EMAIL_ID";
	public static final String PHONE_NO = "PHONE_NO";	
	public static final String COOLDOWN_HOURS = "COOLDOWN_HOURS";
	public static final String DATE_CREATED = "DATE_CREATED";
	public static final String RULE_EDITOR_USER_CONFIG_ID = "RULE_EDITOR_USER_CONFIG_ID";
	public static final String RULE_COUNT = "RULE_COUNT";
	public static final String CNT = "CNT";
	public static final String UNKNOWN = "UNKNOWN";
	public static final String SENT = "SENT";
	public static final String NOTIFIED = "NOTIFIED";
	public static final String SUPPRESS = "SUPPRESS";
	public static final String MUTE = "MUTE";
	public static final String REJECTED = "REJECTED";
	public static final String CAPPING = "CAPPING";
	public static final String FAIL_C = "FAIL";
	public static final String THROTTL = "THROTTL";
	public static final String ERROR_C = "error";
	public static final String RULE_NAME = "RULE_NAME";
	public static final String REGION_NAME = "REGION_NAME";
	public static final String MARKET_NAME = "MARKET_NAME";
	public static final String RULE_SEVERITY = "RULE_SEVERITY";
	public static final String IS_ACTIVE = "IS_ACTIVE";
	public static final String IS_EMAIL = "IS_EMAIL";
	public static final String IS_SMS = "IS_SMS";
	public static final String DATE_MODIFIED = "DATE_MODIFIED";
	
}