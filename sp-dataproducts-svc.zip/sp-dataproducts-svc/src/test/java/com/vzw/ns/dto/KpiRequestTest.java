package com.vzw.ns.dto;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.TextNode;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class KpiRequestTest {

    private KpiRequest request;
    private ObjectMapper mapper = new ObjectMapper();

    @BeforeEach
    void setUp() {
        request = new KpiRequest();
    }

    @Test
    @DisplayName("Type Resolution: Should default to 'event' if type is null or blank")
    void testGetResolvedType() {
        assertEquals("event", request.getResolvedType());

        request.setType("  MARKET  ");
        assertEquals("market", request.getResolvedType());
    }

    @Test
    @DisplayName("Event Node ID: Should extract trimmed text from JsonNode")
    void testGetEventNodeId() {
        request.setNodeID(new TextNode("  NODE123  "));
        assertEquals("NODE123", request.getEventNodeId());

        request.setNodeID(mapper.valueToTree(456));
        assertEquals("456", request.getEventNodeId());

        request.setNodeID(null);
        assertNull(request.getEventNodeId());
    }

    @Test
    @DisplayName("Geofence Nodes: Should handle single value or array in JsonNode")
    void testGetGeofenceNodeIds() {
        // Test Array
        ArrayNode arrayNode = mapper.createArrayNode();
        arrayNode.add("A").add(" B ").add("");
        request.setNodeID(arrayNode);

        List<String> result = request.getGeofenceNodeIds();
        assertEquals(2, result.size());
        assertTrue(result.contains("A") && result.contains("B"));

        // Test Single Text
        request.setNodeID(new TextNode("C"));
        assertEquals("C", request.getGeofenceNodeIds().get(0));
    }

    @Test
    @DisplayName("CSV Conversion: Should correctly join lists into CSV strings")
    void testCsvMethods() {
        // Market CSV
        request.setMarket(Arrays.asList("M1", "  ", "M2"));
        assertEquals("M1,M2", request.getMarketCsv());

        // Geofence CSV
        ArrayNode arrayNode = mapper.createArrayNode();
        arrayNode.add("G1").add("G2");
        request.setNodeID(arrayNode);
        assertEquals("G1,G2", request.getGeofenceNodeIdsCsv());
    }

    @Test
    @DisplayName("DU Sanitization: Should parse string to Integer or return null on error")
    void testGetSanitizedDu() {
        request.setDu(" 123 ");
        assertEquals(123, request.getSanitizedDu());

        request.setDu("invalid");
        assertNull(request.getSanitizedDu());

        request.setDu(null);
        assertNull(request.getSanitizedDu());
    }

    @Test
    @DisplayName("Validation: Should enforce mandatory fields for different flows")
    void testGetValidationError() {
        // 1. Missing Base Fields
        assertNotNull(request.getValidationError());

        // 2. Setup Base Fields
        request.setUserId("user1");
        request.setStartDate("2026-01-01");
        request.setEndDate("2026-01-02");

        // 3. Event flow (default) - missing nodeID
        assertTrue(request.getValidationError().contains("nodeID"));

        // 4. Market flow - missing market list
        request.setType("market");
        assertTrue(request.getValidationError().contains("market"));

        // 5. Valid Market Flow
        request.setMarket(Arrays.asList("M1"));
        assertNull(request.getValidationError());

        // 6. Invalid Type
        request.setType("invalid_type");
        assertTrue(request.getValidationError().contains("Invalid type"));
    }

    @Test
    @DisplayName("Lombok: Verify basic data integrity")
    void testLombokIntegrity() {
        request.setSeverity("Major");
        assertEquals("Major", request.getSeverity());
        assertTrue(request.toString().contains("severity=Major"));
    }
}