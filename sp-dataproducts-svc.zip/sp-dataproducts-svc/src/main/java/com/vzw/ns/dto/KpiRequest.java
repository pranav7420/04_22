package com.vzw.ns.dto;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.databind.JsonNode;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
public class KpiRequest {

    /**
     * Can be:
     * 1) String for event flow
     * 2) Array for geofence flow
     */
    private JsonNode nodeID;

    @JsonAlias({ "DU", "du" })
    private String du;

    private List<String> market;

    /**
     * event / market / geofence
     * If null or blank -> event
     */
    private String type;

    private String startDate;
    private String endDate;
    private String userId;
    private String severity = "Critical";

    public String getResolvedType() {
        return (type == null || type.trim().isEmpty())
                ? "event"
                : type.trim().toLowerCase(Locale.ROOT);
    }

    public String getEventNodeId() {
        if (nodeID == null || nodeID.isNull()) {
            return null;
        }
        if (nodeID.isTextual() || nodeID.isNumber()) {
            return nodeID.asText().trim();
        }
        return null;
    }

    public List<String> getGeofenceNodeIds() {
        if (nodeID == null || nodeID.isNull()) {
            return Collections.emptyList();
        }

        if (nodeID.isArray()) {
            return StreamSupport.stream(nodeID.spliterator(), false)
                    .map(JsonNode::asText)
                    .map(String::trim)
                    .filter(s -> !s.isEmpty())
                    .collect(Collectors.toList());
        }

        if (nodeID.isTextual() || nodeID.isNumber()) {
            String value = nodeID.asText().trim();
            return value.isEmpty() ? Collections.emptyList() : Collections.singletonList(value);
        }

        return new ArrayList<>();
    }

    public String getGeofenceNodeIdsCsv() {
        List<String> ids = getGeofenceNodeIds();
        return ids.isEmpty() ? null : String.join(",", ids);
    }

    public String getMarketCsv() {
        if (market == null || market.isEmpty()) {
            return null;
        }

        List<String> clean = market.stream()
                .filter(s -> s != null && !s.trim().isEmpty())
                .map(String::trim)
                .collect(Collectors.toList());

        return clean.isEmpty() ? null : String.join(",", clean);
    }

    public Integer getSanitizedDu() {
        if (du == null || du.trim().isEmpty()) {
            return null;
        }
        try {
            return Integer.parseInt(du.trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }

    public String getValidationError() {
        if (userId == null || userId.trim().isEmpty()
                || startDate == null || startDate.trim().isEmpty()
                || endDate == null || endDate.trim().isEmpty()) {
            return "Mandatory fields missing: userId, startDate, or endDate";
        }

        String resolvedType = getResolvedType();

        switch (resolvedType) {
            case "event":
                if (getEventNodeId() == null || getEventNodeId().isEmpty()) {
                    return "Mandatory fields missing for event flow: nodeID";
                }
                return null;

            case "market":
                if (market == null || market.isEmpty()) {
                    return "Mandatory fields missing for market flow: market";
                }
                return null;

            case "geofence":
                if (getGeofenceNodeIds().isEmpty()) {
                    return "Mandatory fields missing for geofence flow: nodeID";
                }
                return null;

            default:
                return "Invalid type. Supported values are: event, market, geofence";
        }
    }
}