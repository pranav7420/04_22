package com.vzw.ns.dto;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

class AffectedKpiDetailTest {

    @Test
    @DisplayName("Constructor: Should correctly initialize object using AllArgsConstructor")
    void testAllArgsConstructor() {
        // Arrange
        String kpiName = "RRC_Setup_Failure";
        List<String> hours = Arrays.asList("09", "10", "11");

        // Act
        AffectedKpiDetail detail = new AffectedKpiDetail(kpiName, hours);

        // Assert
        assertEquals(kpiName, detail.getKpiName());
        assertEquals(hours, detail.getHrAffected());
    }

    @Test
    @DisplayName("Constructor: Should correctly initialize object using NoArgsConstructor")
    void testNoArgsConstructor() {
        // Act
        AffectedKpiDetail detail = new AffectedKpiDetail();

        // Assert
        assertNull(detail.getKpiName());
        assertNull(detail.getHrAffected());
    }

    @Test
    @DisplayName("Setters/Getters: Should set and retrieve values correctly")
    void testSettersAndGetters() {
        // Arrange
        AffectedKpiDetail detail = new AffectedKpiDetail();
        String kpiName = "Downlink_Throughput";
        List<String> hours = Arrays.asList("14", "15");

        // Act
        detail.setKpiName(kpiName);
        detail.setHrAffected(hours);

        // Assert
        assertEquals(kpiName, detail.getKpiName());
        assertEquals(hours, detail.getHrAffected());
    }

    @Test
    @DisplayName("Lombok: Should verify toString, equals, and hashCode")
    void testLombokMethods() {
        // Arrange
        List<String> hours = Arrays.asList("01");
        AffectedKpiDetail detail1 = new AffectedKpiDetail("KPI", hours);
        AffectedKpiDetail detail2 = new AffectedKpiDetail("KPI", hours);

        // Assert Equals and HashCode
        assertEquals(detail1, detail2);
        assertEquals(detail1.hashCode(), detail2.hashCode());

        // Assert toString
        assertNotNull(detail1.toString());
        assertEquals(true, detail1.toString().contains("kpiName=KPI"));
    }
}