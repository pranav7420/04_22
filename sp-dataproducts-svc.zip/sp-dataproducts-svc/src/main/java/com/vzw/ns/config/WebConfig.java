package com.vzw.ns.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {
	
	
    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**")
                .allowedOriginPatterns("*"
                  /*  "http://*:7000", 
                    "http://localhost:8000",
                    "http://ns-convergedui-dev.ebiz.verizon.com",
                    "http://ns-convergedui.verizon.com",
                    "http://airwave-spog.ebiz.verizon.com",// Any HTTP host on port 7000
                    "https://localhost:8000",
                    "https://ns-convergedui-dev.ebiz.verizon.com",
                    "https://ns-convergedui.verizon.com",
                    "https://airwave-spog.ebiz.verizon.com",
                    "https://*:7000"     // Any HTTPS host on port 7000*/
                    
                )
                .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")
                .allowedHeaders("*")
                .allowCredentials(true)
                .maxAge(3600);
    }
    
   
}