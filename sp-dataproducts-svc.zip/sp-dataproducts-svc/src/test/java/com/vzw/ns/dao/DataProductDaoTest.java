package com.vzw.ns.dao;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.contains;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.JdbcTemplate;

@ExtendWith(MockitoExtension.class)
public class DataProductDaoTest {

    @Mock
    private JdbcTemplate jdbcTemplate;

    @InjectMocks
    private DataProductDao dataProductDao;

    @Test
    void fetchKpiData_CallsStoredProcedure() {
        dataProductDao.fetchKpiData(
                "event",
                "NODE1",
                1,
                null,
                null,
                "start",
                "end",
                "high"
        );

        verify(jdbcTemplate).queryForList(
                eq("{call SP_GET_SLEEPY_CELL_DATA_SPDB_4G_5G(?, ?, ?, ?, ?, ?, ?, ?)}"),
                eq("event"),
                eq("NODE1"),
                eq(1),
                eq(null),
                eq(null),
                eq("start"),
                eq("end"),
                eq("high")
        );
    }

    @Test
    void fetchKpiData_CallsStoredProcedure_ForMarketFlow() {
        dataProductDao.fetchKpiData(
                "market",
                null,
                null,
                "071,072,073",
                null,
                "start",
                "end",
                "Critical"
        );

        verify(jdbcTemplate).queryForList(
                eq("{call SP_GET_SLEEPY_CELL_DATA_SPDB_4G_5G(?, ?, ?, ?, ?, ?, ?, ?)}"),
                eq("market"),
                eq(null),
                eq(null),
                eq("071,072,073"),
                eq(null),
                eq("start"),
                eq("end"),
                eq("Critical")
        );
    }

    @Test
    void fetchKpiData_CallsStoredProcedure_ForGeofenceFlow() {
        dataProductDao.fetchKpiData(
                "geofence",
                null,
                null,
                null,
                "0720001,0729209,0729204",
                "start",
                "end",
                "Critical"
        );

        verify(jdbcTemplate).queryForList(
                eq("{call SP_GET_SLEEPY_CELL_DATA_SPDB_4G_5G(?, ?, ?, ?, ?, ?, ?, ?)}"),
                eq("geofence"),
                eq(null),
                eq(null),
                eq(null),
                eq("0720001,0729209,0729204"),
                eq("start"),
                eq("end"),
                eq("Critical")
        );
    }
    
    @Test
    @DisplayName("fetchKpiConfig: Should call jdbcTemplate with correct SQL and arguments")
    void fetchKpiConfig_Success() {
        // Arrange
        String vendor = "Ericsson";
        String tech = "5G";
        String region = "North";
        String category = "SleepyCell";
        
        List<Map<String, Object>> mockResult = new ArrayList<>();
        when(jdbcTemplate.queryForList(anyString(), eq(vendor), eq(tech), eq(region), eq(category)))
                .thenReturn(mockResult);

        // Act
        List<Map<String, Object>> result = dataProductDao.fetchKpiConfig(vendor, tech, region, category);

        // Assert
        verify(jdbcTemplate, times(1)).queryForList(
                contains("SELECT * FROM SPDB_RULES_ADMIN"), 
                eq(vendor), eq(tech), eq(region), eq(category)
        );
        assertEquals(mockResult, result);
    }

    @Test
    @DisplayName("upsertKpiConfig: Should call stored procedure with parameter array")
    void upsertKpiConfig_Success() {
        // Arrange
        Object[] params = new Object[] { "Param1", "Param2", "Param3", "Param4", "Param5", "Param6", "Param7", "Param8", "Param9", "Param10", "Param11", "Param12" };

        // Act
        dataProductDao.upsertKpiConfig(params);

        // Assert
        verify(jdbcTemplate, times(1)).update(
                eq("CALL SPDB_RULES_ADMIN_UPSERT(?,?,?,?,?,?,?,?,?,?,?,?)"),
                eq(params)
        );
    }
}