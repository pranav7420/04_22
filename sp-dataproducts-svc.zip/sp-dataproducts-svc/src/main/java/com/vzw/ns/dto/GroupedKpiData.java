package com.vzw.ns.dto;

import java.util.Map;
import java.util.Set;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class GroupedKpiData {
    private String day;
    private String market;
    private String enodeb;
    private Integer du;
    private Integer sector;
    private Integer carrier;
    private String technology;
    private String vendor;
    private String site_name;
    private String site_type;
    private String bandClass;
    private String severity;
    private Set<String> affectedKpisSet;
    private Map<String, Set<String>> affectedKpiTicketsMap;
    private String latestStartDate;
    private Map<String, Object> latestRow;
}