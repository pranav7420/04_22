package com.vzw.ns.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class AffectedKpiDetail {

	public AffectedKpiDetail() {
		
	}
	private String kpiName;
    private List<String> hrAffected;
	
}
