package com.vzw.ns.dto;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

class KpiResponseTest {

    @Test
    @DisplayName("Constructor: Should correctly initialize data via parameterized constructor")
    void testParameterizedConstructor() {
        // Arrange: Create a list of mock data (common in your Service results)
        List<Map<String, Object>> mockData = new ArrayList<>();
        Map<String, Object> item = new HashMap<>();
        item.put("day", "2026-04-20");
        mockData.add(item);

        // Act
        KpiResponse response = new KpiResponse(mockData);

        // Assert
        assertNotNull(response.getData());
        assertEquals(1, response.getData().size());
        assertEquals("2026-04-20", ((Map<String, Object>) response.getData().get(0)).get("day"));
    }

    @Test
    @DisplayName("Constructor: Should initialize with null data via default constructor")
    void testDefaultConstructor() {
        // Act
        KpiResponse response = new KpiResponse();

        // Assert
        assertNull(response.getData());
    }

    @Test
    @DisplayName("Setters/Getters: Should set and retrieve data correctly")
    void testSettersAndGetters() {
        // Arrange
        KpiResponse response = new KpiResponse();
        List<String> mockList = new ArrayList<>();
        mockList.add("Test Data");

        // Act
        response.setData(mockList);

        // Assert
        assertNotNull(response.getData());
        assertEquals("Test Data", response.getData().get(0));
    }

    @Test
    @DisplayName("Generics: Should handle empty list correctly")
    void testEmptyList() {
        // Act
        KpiResponse response = new KpiResponse(new ArrayList<>());

        // Assert
        assertNotNull(response.getData());
        assertEquals(0, response.getData().size());
    }
}