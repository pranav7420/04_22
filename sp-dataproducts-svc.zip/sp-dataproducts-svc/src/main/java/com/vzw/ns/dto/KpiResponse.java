package com.vzw.ns.dto;

import java.util.List;

public class KpiResponse {
	    private List<?> data;

	    public KpiResponse() {}

	    public KpiResponse(List<?> data) {
	        this.data = data;
	    }

	    public List<?> getData() {
	        return data;
	    }

	    public void setData(List<?> data) {
	        this.data = data;
	    }
	}
