package com.vzw.ns.dto;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class ConfigRequest {
	
	
	    private String vendor;
	    private String technology;
	    private String region;
	    private String category;

	  

}
