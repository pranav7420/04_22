package com.vzw.ns.config;

import org.junit.jupiter.api.Test;
import org.springframework.util.ReflectionUtils;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;

import java.lang.reflect.Field;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class WebConfigTest {
	
	@SuppressWarnings("unchecked")
    private CorsConfiguration getFirstCorsConfiguration(CorsRegistry registry) throws Exception {
        Field regsField = ReflectionUtils.findField(CorsRegistry.class, "registrations");
        assertNotNull(regsField, "registrations field not found");
        ReflectionUtils.makeAccessible(regsField);
        List<Object> registrations = (List<Object>) ReflectionUtils.getField(regsField, registry);
        assertNotNull(registrations);
        assertFalse(registrations.isEmpty(), "No CORS registrations found");

        Object registration = registrations.get(0);
        Field configField = ReflectionUtils.findField(registration.getClass(), "config");
        assertNotNull(configField, "config field not found on registration");
        ReflectionUtils.makeAccessible(configField);
        return (CorsConfiguration) ReflectionUtils.getField(configField, registration);
    }

    @Test
    void addCorsMappings_configuresExpectedSettings() throws Exception {
        WebConfig config = new WebConfig();
        CorsRegistry registry = new CorsRegistry();

        config.addCorsMappings(registry);

        CorsConfiguration cors = getFirstCorsConfiguration(registry);
        assertNotNull(cors);

        // Allowed origin patterns
        List<String> originPatterns = cors.getAllowedOriginPatterns();
        assertNotNull(originPatterns);
        assertTrue(originPatterns.contains("*"));
        
        //assertTrue(originPatterns.contains("https://*:7000"));
     

        // Allowed methods
        List<String> methods = cors.getAllowedMethods();
        assertNotNull(methods);
        assertTrue(methods.contains("GET"));
        assertTrue(methods.contains("POST"));
        assertTrue(methods.contains("PUT"));
        assertTrue(methods.contains("DELETE"));
        assertTrue(methods.contains("OPTIONS"));

        // Allowed headers
        List<String> headers = cors.getAllowedHeaders();
        assertNotNull(headers);
        assertTrue(headers.contains("*"));

        // Credentials and max age
        assertTrue(Boolean.TRUE.equals(cors.getAllowCredentials()));
        assertEquals(3600L, cors.getMaxAge());
    }

    @Test
    void addCorsMappings_registersPathPatternAll() throws Exception {
        WebConfig config = new WebConfig();
        CorsRegistry registry = new CorsRegistry();

        config.addCorsMappings(registry);

        CorsConfiguration cors = getFirstCorsConfiguration(registry);
        // Path patterns are stored in registration, but Spring applies it to all (“/**”).
        // We can’t read it directly from CorsConfiguration; just validate non-null config.
        assertNotNull(cors);
    }
}