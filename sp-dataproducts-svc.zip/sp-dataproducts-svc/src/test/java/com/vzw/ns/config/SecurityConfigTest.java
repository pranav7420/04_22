package com.vzw.ns.config;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
public class SecurityConfigTest {

    @Autowired
    private MockMvc mockMvc;

    @Test
    @DisplayName("Security: Should allow access to all endpoints (permitAll)")
    void shouldAllowAccessToAllEndpoints() throws Exception {
        // Since requestMatchers("/**").permitAll() is configured, 
        // any random path should return 200 (or 404 if the controller doesn't exist, 
        // but NOT 401/403)
        mockMvc.perform(get("/any-random-api"))
               .andExpect(status().isNotFound()); // NotFound is fine, as long as it's not Forbidden
    }

    @Test
    @DisplayName("Security: Should have CSRF disabled")
    void shouldHaveCsrfDisabled() throws Exception {
        // If CSRF was enabled, a POST request without a token would return 403 Forbidden.
        // With CSRF disabled, it should proceed to the next layer (404/200).
        mockMvc.perform(post("/any-post-endpoint"))
               .andExpect(status().isNotFound()); // Confirms CSRF did not block the request
    }
}