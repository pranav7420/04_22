package com.vzw.ns.util;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

@Component
public class GeneralUtility {

	public static final Logger logger = LoggerFactory.getLogger(GeneralUtility.class);

	public static boolean isEmpty(String str) {
		return (str == null || str.trim().equals(""));
	}

	public static boolean isNonEmpty(String str) {
		return !isEmpty(str);
	}

	public static String trim(String str) {
		if (str != null) {
			str = str.trim();
		}
		return str;
	}

	public static void closeCRS(Connection C, ResultSet R, Statement S) {
		try {
			if (R != null) {
				R.close();
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		try {
			if (S != null) {
				S.close();
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		try {
			if (C != null) {
				C.close();
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}
	

}
