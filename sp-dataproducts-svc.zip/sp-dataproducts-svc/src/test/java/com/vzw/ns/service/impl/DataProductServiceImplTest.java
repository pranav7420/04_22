package com.vzw.ns.service.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.when;

import java.util.*;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.vzw.ns.dao.DataProductDao;
import com.vzw.ns.dto.ConfigRequest;
import com.vzw.ns.dto.KpiRequest;
import com.vzw.ns.dto.KpiResponse;
import com.vzw.ns.dto.UpdateConfigRequest;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

@ExtendWith(MockitoExtension.class)
public class DataProductServiceImplTest {

    @Mock
    private DataProductDao dataProductDao;

    @Spy
    private ObjectMapper objectMapper = new ObjectMapper();

    @InjectMocks
    private DataProductServiceImpl service;

    private KpiRequest validRequest;

    @BeforeEach
    void setUp() {
        validRequest = new KpiRequest();
        validRequest.setNodeID(objectMapper.valueToTree("TEST_NODE"));
        validRequest.setUserId("admin");
        validRequest.setStartDate("2026-01-01");
        validRequest.setEndDate("2026-01-02");
        validRequest.setType("event");
    }

    @Test
    void getAffectedKpiData_GroupsCorrectly_AndCollectsTicketIds() {
        List<Map<String, Object>> mockRawData = new ArrayList<>();

        Map<String, Object> row1 = new HashMap<>();
        row1.put("AFFECTED_KPI", "KPI_A");
        row1.put("STARTDATE", "2026-04-01 10:00:00");
        row1.put("GNODEB", "G1");
        row1.put("DU", 3219);
        row1.put("SECTOR", 1);
        row1.put("CARRIER", 1);
        row1.put("ENODEB_DU_SECTOR_CARRIER", "G1_3219_1_1");
        row1.put("HRS_AFFECTED", "10,11");
        row1.put("TECHNOLOGY", "5GNR");
        row1.put("FREQUENCY_BAND", "n77");
        row1.put("MARKET_ID", "072");
        row1.put("VENDOR", "Samsung");
        row1.put("SITE_NAME", "ABC");
        row1.put("SITE_TYPE", "Macro");
        row1.put("SEVERITY", "Critical");
        row1.put("SC_CONSECUTIVE_DURATION", 5);
        row1.put("SLEPPYCELL_OCCUR_D", 10);
        row1.put("WoW_TREND", "21.5");
        row1.put("30D_VOLUME_AVERAGE", 11.2);
        row1.put("TICKET_ID", "VW00709943");
        row1.put("TICKET_CLOSE_STATUS", "Failure");

        Map<String, Object> row2 = new HashMap<>();
        row2.put("AFFECTED_KPI", "KPI_B");
        row2.put("STARTDATE", "2026-04-01 11:00:00");
        row2.put("GNODEB", "G1");
        row2.put("DU", 3219);
        row2.put("SECTOR", 1);
        row2.put("CARRIER", 1);
        row2.put("ENODEB_DU_SECTOR_CARRIER", "G1_3219_1_1");
        row2.put("HRS_AFFECTED", "10,11");
        row2.put("TECHNOLOGY", "5GNR");
        row2.put("FREQUENCY_BAND", "n77");
        row2.put("MARKET_ID", "072");
        row2.put("VENDOR", "Samsung");
        row2.put("SITE_NAME", "ABC");
        row2.put("SITE_TYPE", "Macro");
        row2.put("SEVERITY", "Critical");
        row2.put("SC_CONSECUTIVE_DURATION", 6);
        row2.put("SLEPPYCELL_OCCUR_D", 12);
        row2.put("WoW_TREND", "24.5");
        row2.put("30D_VOLUME_AVERAGE", 12.2);
        row2.put("TICKET_ID", "VW00708160");
        row2.put("TICKET_CLOSE_STATUS", null);

        mockRawData.add(row1);
        mockRawData.add(row2);

        when(dataProductDao.fetchKpiData(
                anyString(),
                any(),
                any(),
                any(),
                any(),
                anyString(),
                anyString(),
                anyString()
        )).thenReturn(mockRawData);

        KpiResponse response = service.getAffectedKpiData(validRequest);

        assertEquals(1, response.getData().size());

        Map<String, Object> group = (Map<String, Object>) response.getData().get(0);
        List<Map<String, Object>> affectedKpis = (List<Map<String, Object>>) group.get("affectedKpis");

        assertEquals(2, affectedKpis.size());

        Map<String, Object> firstKpi = affectedKpis.get(0);
        Map<String, Object> secondKpi = affectedKpis.get(1);

        assertEquals(true, firstKpi.containsKey("ticketId"));
        assertEquals(true, secondKpi.containsKey("ticketId"));
    }

    @Test
    void getAffectedKpiData_DoesNotIncludeClosedTickets() {
        List<Map<String, Object>> mockRawData = new ArrayList<>();

        Map<String, Object> row = new HashMap<>();
        row.put("AFFECTED_KPI", "KPI_A");
        row.put("STARTDATE", "2026-04-01 10:00:00");
        row.put("GNODEB", "G1");
        row.put("SECTOR", 1);
        row.put("CARRIER", 1);
        row.put("ENODEB_SECTOR_CARRIER", "G1_1_1");
        row.put("HRS_AFFECTED", "10,11");
        row.put("TECHNOLOGY", "4G");
        row.put("BAND_CLASS", "B13");
        row.put("MARKET_ID", "072");
        row.put("VENDOR", "Samsung");
        row.put("SITE_NAME", "ABC");
        row.put("SITE_TYPE", "Macro");
        row.put("SEVERITY", "Critical");
        row.put("SC_CONSECUTIVE_DURATION", 5);
        row.put("SLEPPYCELL_OCCUR_D", 10);
        row.put("WoW_TREND", "21.5");
        row.put("30D_VOLUME_AVERAGE", 11.2);
        row.put("TICKET_ID", "VW00999999");
        row.put("TICKET_CLOSE_STATUS", "Success");

        mockRawData.add(row);

        when(dataProductDao.fetchKpiData(
                anyString(),
                any(),
                any(),
                any(),
                any(),
                anyString(),
                anyString(),
                anyString()
        )).thenReturn(mockRawData);

        KpiResponse response = service.getAffectedKpiData(validRequest);

        Map<String, Object> group = (Map<String, Object>) response.getData().get(0);
        List<Map<String, Object>> affectedKpis = (List<Map<String, Object>>) group.get("affectedKpis");
        Map<String, Object> kpi = affectedKpis.get(0);

        List<String> ticketIds = (List<String>) kpi.get("ticketId");
        assertEquals(0, ticketIds.size());
    }

    @Test
    void getAffectedKpiData_ThrowsExceptionOnMissingFields() {
        KpiRequest emptyRequest = new KpiRequest();
        assertThrows(IllegalArgumentException.class, () -> service.getAffectedKpiData(emptyRequest));
    }

    @Test
    void getAffectedKpiData_AllowsMarketFlowWithoutNodeId() {
        KpiRequest request = new KpiRequest();
        request.setType("market");
        request.setMarket(Arrays.asList("071", "072"));
        request.setUserId("admin");
        request.setStartDate("2026-01-01");
        request.setEndDate("2026-01-02");

        when(dataProductDao.fetchKpiData(
                anyString(),
                any(),
                any(),
                any(),
                any(),
                anyString(),
                anyString(),
                anyString()
        )).thenReturn(new ArrayList<>());

        KpiResponse response = service.getAffectedKpiData(request);

        assertEquals(0, response.getData().size());
    }
    
    @Test
    void getSleepyCellConfigXlpt_Success_ReturnsFormattedConfig() throws Exception {
        // Prepare Request
        ConfigRequest request = new ConfigRequest();
        request.setVendor("Ericsson");
        request.setTechnology("5G");
        request.setRegion("North");
        request.setCategory("SleepyCell");

        // Mock DB Row with JSON strings
        Map<String, Object> mockRow = new HashMap<>();
        mockRow.put("TECHNOLOGY", "5G");
        mockRow.put("VENDOR", "Ericsson");
        mockRow.put("REGION", "North");
        mockRow.put("JSON_FORMULA", "{\"threshold\": 10}");
        mockRow.put("JSON_PRIORITY", "{\"level\": \"High\"}");
        mockRow.put("JSON_READONLY_FORMULA", "[\"Kpi1\", \"Kpi2\"]");

        when(dataProductDao.fetchKpiConfig(anyString(), anyString(), anyString(), anyString()))
                .thenReturn(Collections.singletonList(mockRow));

        // Execute
        Map<String, Object> result = service.getSleepyCellConfigXlpt(request);

        // Verify Structure
        assertEquals("5G", result.get("technology"));
        assertTrue(result.get("market_kpis") instanceof List);
        
        List<Object> marketKpis = (List<Object>) result.get("market_kpis");
        // Verify JSON was parsed into Maps/Lists by ObjectMapper
        assertTrue(marketKpis.get(0) instanceof Map); 
        assertTrue(result.get("national_kpis") instanceof List);
    }

    @Test
    void getSleepyCellConfigXlpt_NoDataFound_ReturnsMessage() {
        ConfigRequest request = new ConfigRequest();
        request.setVendor("Nokia");
        request.setTechnology("4G");
        request.setRegion("South");
        request.setCategory("SleepyCell");

        when(dataProductDao.fetchKpiConfig(anyString(), anyString(), anyString(), anyString()))
                .thenReturn(new ArrayList<>());

        Map<String, Object> result = service.getSleepyCellConfigXlpt(request);

        assertEquals("No data found for the given criteria", result.get("message"));
    }

    @Test
    void getSleepyCellConfigXlpt_InvalidRequest_ThrowsException() {
        ConfigRequest incompleteRequest = new ConfigRequest(); // Missing fields
        
        assertThrows(IllegalArgumentException.class, () -> 
            service.getSleepyCellConfigXlpt(incompleteRequest)
        );
    }

    @Test
    void updateSleepyCellConfigXlpt_Success_ReturnsSuccessResponse() throws Exception {
        // Setup Update Request
        UpdateConfigRequest updateReq = new UpdateConfigRequest();
        updateReq.setTechnology("5G");
        updateReq.setVendor("Ericsson");
        updateReq.setRegion("North");
        updateReq.setReq_type("update");
        updateReq.setRequest_by("user123");

        // Mock Market KPIs (List of 2 Maps: Formula and Priority)
        Map<String, Object> formula = new HashMap<>();
        formula.put("kpi_name", "DropRate");
        Map<String, Object> priority = new HashMap<>();
        priority.put("priority_settings", "P1");
        priority.put("kpi_short_name", "DR");
        
        updateReq.setMarket_kpis(Arrays.asList(formula, priority));

        // Execute
        Map<String, Object> result = service.updateSleepyCellConfigXlpt(updateReq);

        // Verify
        assertEquals("success", result.get("status"));
        assertTrue(result.get("message").toString().contains("reviewed by RF Team"));
    }

 
    @Test
    void parseJsonField_InvalidJson_ReturnsOriginalString() {
        // Use a row that contains malformed JSON
        ConfigRequest request = new ConfigRequest();
        request.setVendor("Ericsson");
        request.setTechnology("5G");
        request.setRegion("North");
        request.setCategory("SleepyCell");

        Map<String, Object> mockRow = new HashMap<>();
        mockRow.put("TECHNOLOGY", "5G");
        mockRow.put("JSON_FORMULA", "{malformed_json}"); // Invalid JSON

        when(dataProductDao.fetchKpiConfig(anyString(), anyString(), anyString(), anyString()))
                .thenReturn(Collections.singletonList(mockRow));

        Map<String, Object> result = service.getSleepyCellConfigXlpt(request);
        
        List<Object> marketKpis = (List<Object>) result.get("market_kpis");
        // Should return the string as-is because parsing failed
        assertEquals("{malformed_json}", marketKpis.get(0));
    }
    
    @Test
    void getCellIdentifier_LogicTests() {
        // Scenario 1: 5G Key is present (Highest Priority)
        Map<String, Object> row5g = new HashMap<>();
        row5g.put("ENODEB_DU_SECTOR_CARRIER", "5G_NODE_123");
        row5g.put("ENODEB_SECTOR_CARRIER", "4G_NODE_456"); // Should be ignored
        
        String result5g = ReflectionTestUtils.invokeMethod(service, "getCellIdentifier", row5g);
        assertEquals("5G_NODE_123", result5g);

        // Scenario 2: 5G Key is missing, 4G Key is present
        Map<String, Object> row4g = new HashMap<>();
        row4g.put("ENODEB_SECTOR_CARRIER", "4G_NODE_456");
        
        String result4g = ReflectionTestUtils.invokeMethod(service, "getCellIdentifier", row4g);
        assertEquals("4G_NODE_456", result4g);

        // Scenario 3: Specific keys missing, but DU is present
        Map<String, Object> rowDu = new HashMap<>();
        rowDu.put("GNODEB", "G1");
        rowDu.put("DU", "D1");
        rowDu.put("SECTOR", "S1");
        rowDu.put("CARRIER", "C1");
        
        String resultDu = ReflectionTestUtils.invokeMethod(service, "getCellIdentifier", rowDu);
        assertEquals("G1|D1|S1|C1", resultDu);

        // Scenario 4: Fallback (No DU, no specific keys)
        Map<String, Object> rowFallback = new HashMap<>();
        rowFallback.put("GNODEB", "G1");
        rowFallback.put("SECTOR", "S1");
        rowFallback.put("CARRIER", "C1");
        
        String resultFallback = ReflectionTestUtils.invokeMethod(service, "getCellIdentifier", rowFallback);
        assertEquals("G1|S1|C1", resultFallback);
        
        // Scenario 5: Handling nulls in fallback
        Map<String, Object> rowNulls = new HashMap<>();
        String resultNulls = ReflectionTestUtils.invokeMethod(service, "getCellIdentifier", rowNulls);
        assertEquals("||", resultNulls); // Joins three empty strings
    }
    
   

    // Helper to create mock DB rows
    private Map<String, Object> createRow(String kpi, String start, String enodeb, Integer du, Integer sector, Integer carrier) {
        Map<String, Object> row = new HashMap<>();
        row.put("AFFECTED_KPI", kpi);
        row.put("STARTDATE", start);
        row.put("MARKET_ID", "MRK1");
        row.put("GNODEB", enodeb);
        row.put("DU", du);
        row.put("SECTOR", sector);
        row.put("CARRIER", carrier);
        row.put("TECHNOLOGY", "5G");
        row.put("VENDOR", "V1");
        row.put("HRS_AFFECTED", "1,2");
        return row;
    }
    
    @Test
    void compareNullableInt_LogicTests() {
        // Both null (treated as -1 vs -1)
        int bothNull = ReflectionTestUtils.invokeMethod(service, "compareNullableInt", null, null);
        assertEquals(0, bothNull);

        // First null (treated as -1 vs 5)
        int firstNull = ReflectionTestUtils.invokeMethod(service, "compareNullableInt", null, 5);
        assertTrue(firstNull < 0);

        // Second null (treated as 5 vs -1)
        int secondNull = ReflectionTestUtils.invokeMethod(service, "compareNullableInt", 5, null);
        assertTrue(secondNull > 0);

        // Both non-null (equal)
        int equal = ReflectionTestUtils.invokeMethod(service, "compareNullableInt", 10, 10);
        assertEquals(0, equal);

        // Both non-null (A < B)
        int less = ReflectionTestUtils.invokeMethod(service, "compareNullableInt", 5, 10);
        assertTrue(less < 0);
    }
}